const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true 
    },
    regNo: { 
        type: String, 
        required: true, 
        unique: true 
    },
    password: { 
        type: String, 
        required: true 
    },
    // Updated enum to include 'Parent'
    role: { 
        type: String, 
        enum: ['Student', 'Faculty', 'Admin', 'Parent'], 
        default: 'Student' 
    },
    
    // Links a Parent user to a Student's regNo
    childRegNo: { 
        type: String,
        default: null 
    },

    // Core VTOP logic fields for Students
    registeredCourses: [{
        courseCode: String,
        courseName: String,
        slot: String, // e.g., A1, B1, L1+L2
        credits: { type: Number, default: 0 },
        attendance: { type: Number, default: 0 },
        marks: { type: Number, default: 0 }
    }],
    
    // Used to enforce the 27-credit limit
    totalCredits: { 
        type: Number, 
        default: 0 
    } 
});

module.exports = mongoose.model('User', UserSchema);