const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// @route   GET api/parent/child-progress
// @desc    Parent views their child's courses and marks
router.get('/child-progress', auth, async (req, res) => {
    try {
        // Ensure only a Parent can access this
        if (req.user.role !== 'Parent') {
            return res.status(403).json({ msg: "Access denied. Parent only." });
        }

        // 1. Find the parent record to get the linked child's RegNo
        const parent = await User.findById(req.user.id);
        
        // 2. Find the child using the childRegNo from the seed data
        const child = await User.findOne({ regNo: parent.childRegNo });

        if (!child) {
            return res.status(404).json({ msg: "Child record not found in database." });
        }

        // 3. Return the child's academic data
        res.json({
            parentName: parent.name,
            childName: child.name,
            childRegNo: child.regNo,
            registeredCourses: child.registeredCourses,
            totalCredits: child.totalCredits
        });
    } catch (err) {
        res.status(500).send("Server Error");
    }
});

module.exports = router;