const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// @route   POST api/admin/add-user
// @desc    Admin can manually add new students or faculty
router.post('/add-user', auth, async (req, res) => {
    try {
        // Protect route: Only Admins allowed
        if (req.user.role !== 'Admin') {
            return res.status(403).json({ msg: "Access denied. Admin only." });
        }
        
        const { name, regNo, password, role } = req.body;
        
        let user = await User.findOne({ regNo });
        if (user) return res.status(400).json({ msg: "User already exists" });

        // Create new user (In production, use bcrypt here)
        user = new User({ name, regNo, password, role });
        await user.save();

        res.json({ msg: "User created successfully", user: { name, regNo, role } });
    } catch (err) {
        res.status(500).send("Server Error");
    }
});

module.exports = router;
// @route   POST api/admin/approve-reevaluation
router.post('/approve-reevaluation', auth, async (req, res) => {
    const { studentRegNo, courseCode } = req.body;
    try {
        if (req.user.role !== 'Admin') return res.status(403).json({ msg: "Admin only" });
        // Update logic to set a flag allowing Faculty to edit marks for this student
        res.json({ msg: "Re-evaluation approved. Faculty can now update marks." });
    } catch (err) { res.status(500).send("Server Error"); }
});