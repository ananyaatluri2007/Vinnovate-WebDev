const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

router.post('/register-course', auth, async (req, res) => {
    const { courseCode, courseName, slot, credits } = req.body;

    try {
        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({ msg: 'User not found. Please re-login.' });
        }

        const creditAmount = Number(credits);

        // 1. Credit Limit Check
        if (user.totalCredits + creditAmount > 27) {
            return res.status(400).json({ msg: `Limit exceeded! Current: ${user.totalCredits}. Max: 27` });
        }

        // 2. Slot Clash Check
        if (user.registeredCourses.some(c => c.slot === slot)) {
            return res.status(400).json({ msg: `Slot ${slot} is already occupied.` });
        }

        // 3. Save
        user.registeredCourses.push({ courseCode, courseName, slot, credits: creditAmount });
        user.totalCredits += creditAmount;

        await user.save();
        res.json({ msg: 'Success!', totalCredits: user.totalCredits });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
// @route   GET api/student/profile
router.get('/profile', auth, async (req, res) => {
    try {
        const student = await User.findById(req.user.id).select('-password');
        
        // Calculate attendance percentage for each course
        const coursesWithAttendance = student.registeredCourses.map(course => {
            const percentage = course.totalClasses > 0 
                ? ((course.attended / course.totalClasses) * 100).toFixed(2) 
                : 0;
            return {
                ...course._doc,
                attendancePercentage: `${percentage}%`,
                status: percentage < 75 ? "De-barred (Low Attendance)" : "Eligible"
            };
        });

        res.json({
            name: student.name,
            regNo: student.regNo,
            totalCredits: student.totalCredits,
            courses: coursesWithAttendance
        });
    } catch (err) {
        res.status(500).send("Server Error");
    }
});
// @route   GET api/student/timetable
router.get('/timetable', auth, async (req, res) => {
    try {
        const student = await User.findById(req.user.id);
        // Organize courses by slot (e.g., A1, B1, C1)
        const timetable = student.registeredCourses.reduce((acc, course) => {
            acc[course.slot] = course.courseName;
            return acc;
        }, {});
        res.json(timetable);
    } catch (err) { res.status(500).send("Server Error"); }
});

// @route   POST api/student/request-reevaluation
router.post('/request-reevaluation', auth, async (req, res) => {
    const { courseCode } = req.body;
    try {
        const student = await User.findById(req.user.id);
        const course = student.registeredCourses.find(c => c.courseCode === courseCode);
        course.reEvaluationRequested = true;
        await student.save();
        res.json({ msg: "Re-evaluation request submitted to Admin" });
    } catch (err) { res.status(500).send("Server Error"); }
});
router.get('/download-slip', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        
        // Check if any course has < 75% attendance
        const debarredCourses = user.registeredCourses.filter(course => {
            const percentage = course.totalClasses > 0 ? (course.attended / course.totalClasses) * 100 : 100;
            return percentage < 75;
        });

        if (debarredCourses.length > 0) {
            return res.status(403).json({ 
                msg: "Download Blocked: Attendance below 75% in some courses.",
                courses: debarredCourses.map(c => c.courseCode)
            });
        }

        // ... existing PDF generation code ...
    } catch (err) {
        res.status(500).send("Server Error");
    }
});