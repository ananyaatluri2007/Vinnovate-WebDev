const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs'); // Add this
const User = require('../models/User');

router.post('/login', async (req, res) => {
    const { regNo, password } = req.body;

    try {
        // 1. Find user by regNo
        const user = await User.findOne({ regNo });
        if (!user) {
            return res.status(400).json({ msg: "Invalid Credentials (User not found)" });
        }

        // 2. Compare hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ msg: "Invalid Credentials (Password mismatch)" });
        }

        // 3. Create token with the DB ID
        const payload = { id: user._id, role: user.role };
        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.json({ token, role: user.role });
    } catch (err) {
        res.status(500).send("Server Error");
    }
});

module.exports = router;