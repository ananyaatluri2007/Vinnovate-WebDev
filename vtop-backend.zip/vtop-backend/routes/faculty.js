const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// @route   GET api/faculty/students
// @desc    View all students and their registered courses
router.get('/students', auth, async (req, res) => {
    try {
        // Role check
        if (req.user.role !== 'Faculty') {
            return res.status(403).json({ msg: "Access denied. Faculty only." });
        }

        const students = await User.find({ role: 'Student' }).select('-password');
        res.json(students);
    } catch (err) {
        res.status(500).send("Server Error");
    }
});

// @route   POST api/faculty/update-marks
// @desc    Assign marks to a student's specific course
router.post('/update-marks', auth, async (req, res) => {
    const { studentRegNo, courseCode, marks } = req.body;

    try {
        if (req.user.role !== 'Faculty') {
            return res.status(403).json({ msg: "Access denied." });
        }

        const student = await User.findOne({ regNo: studentRegNo });
        if (!student) return res.status(404).json({ msg: "Student not found" });

        // Find the specific course in the student's record
        const course = student.registeredCourses.find(c => c.courseCode === courseCode);
        
        if (!course) {
            return res.status(404).json({ msg: "Course not found for this student" });
        }

        // Update the marks field
        course.marks = marks;
        await student.save();

        res.json({ 
            msg: "Marks updated successfully", 
            student: student.name, 
            course: courseCode, 
            newMarks: marks 
        });
    } catch (err) {
        res.status(500).send("Server Error");
    }
});

module.exports = router;
// @route   POST api/faculty/mark-attendance
router.post('/mark-attendance', auth, async (req, res) => {
    const { studentRegNo, courseCode, status } = req.body; // status: 'present' or 'absent'

    try {
        if (req.user.role !== 'Faculty') return res.status(403).json({ msg: "Faculty only" });

        const student = await User.findOne({ regNo: studentRegNo });
        const course = student.registeredCourses.find(c => c.courseCode === courseCode);

        if (!course) return res.status(404).json({ msg: "Course not found" });

        // Update attendance
        course.totalClasses += 1;
        if (status === 'present') {
            course.attended += 1;
        }

        await student.save();
        res.json({ msg: "Attendance updated", attendance: `${course.attended}/${course.totalClasses}` });
    } catch (err) {
        res.status(500).send("Server Error");
    }
});
const calculateGrade = (marks) => {
    if (marks >= 90) return 'S';
    if (marks >= 80) return 'A';
    if (marks >= 70) return 'B';
    if (marks >= 60) return 'C';
    if (marks >= 50) return 'D';
    return 'F';
};