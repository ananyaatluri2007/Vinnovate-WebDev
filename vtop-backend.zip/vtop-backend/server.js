const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());

// Direct MongoDB Connection
mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/vtop_university')
    .then(() => console.log('✅ VTOP Database Connected'))
    .catch(err => console.log('❌ DB Error:', err));

// Route Links
app.use('/api/auth', require('./routes/auth'));
app.use('/api/student', require('./routes/student'));
app.use('/api/faculty', require('./routes/faculty')); // Added for Faculty
app.use('/api/parent', require('./routes/parent'));   // Added for Parent

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));